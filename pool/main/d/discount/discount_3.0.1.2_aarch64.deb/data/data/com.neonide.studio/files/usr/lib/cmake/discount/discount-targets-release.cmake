#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "discount::libmarkdown" for configuration "Release"
set_property(TARGET discount::libmarkdown APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(discount::libmarkdown PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libmarkdown.so"
  IMPORTED_SONAME_RELEASE "libmarkdown.so"
  )

list(APPEND _cmake_import_check_targets discount::libmarkdown )
list(APPEND _cmake_import_check_files_for_discount::libmarkdown "/data/data/com.neonide.studio/files/usr/lib/libmarkdown.so" )

# Import target "discount::markdown" for configuration "Release"
set_property(TARGET discount::markdown APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(discount::markdown PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/markdown"
  )

list(APPEND _cmake_import_check_targets discount::markdown )
list(APPEND _cmake_import_check_files_for_discount::markdown "${_IMPORT_PREFIX}/bin/markdown" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
