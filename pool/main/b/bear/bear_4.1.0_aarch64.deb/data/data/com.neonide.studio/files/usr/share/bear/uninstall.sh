#!/data/data/com.neonide.studio/files/usr/bin/sh
# Bear uninstall script
# This script was generated during installation and removes all installed files.
# Usage: sh uninstall.sh

set -e

# Remove bear binaries
rm -f '/data/data/com.neonide.studio/files/usr/share/bear/bin/bear-driver'
rm -f '/data/data/com.neonide.studio/files/usr/share/bear/bin/bear-wrapper'
rmdir '/data/data/com.neonide.studio/files/usr/share/bear/bin' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share/bear' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share' 2>/dev/null || true

# Remove preload library
rm -f '/data/data/com.neonide.studio/files/usr/share/bear/lib/libexec.so'
rmdir '/data/data/com.neonide.studio/files/usr/share/bear/lib' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share/bear' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share' 2>/dev/null || true

# Remove bear entry script
rm -f '/data/data/com.neonide.studio/files/usr/bin/bear'
rmdir '/data/data/com.neonide.studio/files/usr/bin' 2>/dev/null || true

# Remove man page
rm -f '/data/data/com.neonide.studio/files/usr/share/man/man1/bear.1'
rmdir '/data/data/com.neonide.studio/files/usr/share/man/man1' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share/man' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share' 2>/dev/null || true

# Remove documentation
rm -f '/data/data/com.neonide.studio/files/usr/share/doc/bear/README.md'
rm -f '/data/data/com.neonide.studio/files/usr/share/doc/bear/COPYING'
rmdir '/data/data/com.neonide.studio/files/usr/share/doc/bear' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share/doc' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share' 2>/dev/null || true

# Remove uninstall script
rm -f '/data/data/com.neonide.studio/files/usr/share/bear/uninstall.sh'
rmdir '/data/data/com.neonide.studio/files/usr/share/bear' 2>/dev/null || true
rmdir '/data/data/com.neonide.studio/files/usr/share' 2>/dev/null || true

echo 'Bear uninstalled from /data/data/com.neonide.studio/files/usr'
