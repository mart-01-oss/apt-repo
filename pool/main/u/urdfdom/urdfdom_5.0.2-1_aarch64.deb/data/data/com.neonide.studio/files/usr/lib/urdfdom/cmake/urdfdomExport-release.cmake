#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "urdfdom::urdfdom_model" for configuration "Release"
set_property(TARGET urdfdom::urdfdom_model APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(urdfdom::urdfdom_model PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_model.so"
  IMPORTED_SONAME_RELEASE "liburdfdom_model.so"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_model )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_model "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_model.so" )

# Import target "urdfdom::urdfdom_world" for configuration "Release"
set_property(TARGET urdfdom::urdfdom_world APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(urdfdom::urdfdom_world PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_world.so"
  IMPORTED_SONAME_RELEASE "liburdfdom_world.so"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_world )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_world "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_world.so" )

# Import target "urdfdom::urdfdom_sensor" for configuration "Release"
set_property(TARGET urdfdom::urdfdom_sensor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(urdfdom::urdfdom_sensor PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_sensor.so"
  IMPORTED_SONAME_RELEASE "liburdfdom_sensor.so"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_sensor )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_sensor "/data/data/com.neonide.studio/files/usr/lib/liburdfdom_sensor.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
