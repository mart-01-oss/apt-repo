#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "unshield::libunshield" for configuration "Release"
set_property(TARGET unshield::libunshield APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(unshield::libunshield PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libunshield.so"
  IMPORTED_SONAME_RELEASE "libunshield.so"
  )

list(APPEND _cmake_import_check_targets unshield::libunshield )
list(APPEND _cmake_import_check_files_for_unshield::libunshield "/data/data/com.neonide.studio/files/usr/lib/libunshield.so" )

# Import target "unshield::unshield" for configuration "Release"
set_property(TARGET unshield::unshield APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(unshield::unshield PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/unshield"
  )

list(APPEND _cmake_import_check_targets unshield::unshield )
list(APPEND _cmake_import_check_files_for_unshield::unshield "${_IMPORT_PREFIX}/bin/unshield" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
