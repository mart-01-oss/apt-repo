// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2019-2024 Second State INC

//===-- wasmedge/version.h - WasmEdge C API -------------------------------===//
//
// Part of the WasmEdge Project.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the version definitions of the WasmEdge C API.
///
//===----------------------------------------------------------------------===//

#ifndef WASMEDGE_C_API_VERSION_H
#define WASMEDGE_C_API_VERSION_H

// WasmEdge version.
#define WASMEDGE_VERSION "0.15.0"
#define WASMEDGE_VERSION_MAJOR 0
#define WASMEDGE_VERSION_MINOR 15
#define WASMEDGE_VERSION_PATCH 0

#define WasmEdge_Plugin_CurrentAPIVersion 4

#endif // WASMEDGE_C_API_VERSION_H
