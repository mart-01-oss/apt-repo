#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zziplib::libzzip" for configuration "Release"
set_property(TARGET zziplib::libzzip APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zziplib::libzzip PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libzzip-0.so"
  IMPORTED_SONAME_RELEASE "libzzip-0.so"
  )

list(APPEND _cmake_import_check_targets zziplib::libzzip )
list(APPEND _cmake_import_check_files_for_zziplib::libzzip "/data/data/com.neonide.studio/files/usr/lib/libzzip-0.so" )

# Import target "zziplib::libzzipfseeko" for configuration "Release"
set_property(TARGET zziplib::libzzipfseeko APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zziplib::libzzipfseeko PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libzzipfseeko-0.so"
  IMPORTED_SONAME_RELEASE "libzzipfseeko-0.so"
  )

list(APPEND _cmake_import_check_targets zziplib::libzzipfseeko )
list(APPEND _cmake_import_check_files_for_zziplib::libzzipfseeko "/data/data/com.neonide.studio/files/usr/lib/libzzipfseeko-0.so" )

# Import target "zziplib::libzzipmmapped" for configuration "Release"
set_property(TARGET zziplib::libzzipmmapped APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zziplib::libzzipmmapped PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libzzipmmapped-0.so"
  IMPORTED_SONAME_RELEASE "libzzipmmapped-0.so"
  )

list(APPEND _cmake_import_check_targets zziplib::libzzipmmapped )
list(APPEND _cmake_import_check_files_for_zziplib::libzzipmmapped "/data/data/com.neonide.studio/files/usr/lib/libzzipmmapped-0.so" )

# Import target "zziplib::libzzipwrap" for configuration "Release"
set_property(TARGET zziplib::libzzipwrap APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zziplib::libzzipwrap PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libzzipwrap-0.so"
  IMPORTED_SONAME_RELEASE "libzzipwrap-0.so"
  )

list(APPEND _cmake_import_check_targets zziplib::libzzipwrap )
list(APPEND _cmake_import_check_files_for_zziplib::libzzipwrap "/data/data/com.neonide.studio/files/usr/lib/libzzipwrap-0.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
