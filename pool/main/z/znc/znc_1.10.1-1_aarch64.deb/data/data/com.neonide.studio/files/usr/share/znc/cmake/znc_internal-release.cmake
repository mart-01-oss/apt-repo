#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ZNC::internal::znc" for configuration "Release"
set_property(TARGET ZNC::internal::znc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ZNC::internal::znc PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/znc"
  )

list(APPEND _cmake_import_check_targets ZNC::internal::znc )
list(APPEND _cmake_import_check_files_for_ZNC::internal::znc "${_IMPORT_PREFIX}/bin/znc" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
