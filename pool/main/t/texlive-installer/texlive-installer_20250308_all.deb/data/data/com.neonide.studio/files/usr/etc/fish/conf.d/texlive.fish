set -gx --append PATH /data/data/com.neonide.studio/files/usr/bin/texlive
set -gx TEXMFROOT /data/data/com.neonide.studio/files/usr/share/texlive/2025
set -gx TEXMFLOCAL /data/data/com.neonide.studio/files/usr/share/texlive/texmf-local
set -gx OSFONTDIR /data/data/com.neonide.studio/files/usr/share/fonts/TTF
set -gx TRFONTS /data/data/com.neonide.studio/files/usr/share/groff/current/font/devps /data/data/com.neonide.studio/files/usr/share/groff/site-font/devps
