export PATH=$PATH:/data/data/com.neonide.studio/files/usr/bin/texlive
export TEXMFROOT=/data/data/com.neonide.studio/files/usr/share/texlive/2025
export TEXMFLOCAL=/data/data/com.neonide.studio/files/usr/share/texlive/texmf-local
export OSFONTDIR=/data/data/com.neonide.studio/files/usr/share/fonts/TTF
export TRFONTS=/data/data/com.neonide.studio/files/usr/share/groff/{current/font,site-font}/devps
