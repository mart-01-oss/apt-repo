
use builtin;
use str;

set edit:completion:arg-completer[taplo] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'taplo'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'taplo'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand -V 'Print version'
            cand --version 'Print version'
            cand lint 'Lint TOML documents'
            cand format 'Format TOML documents'
            cand lsp 'Language server operations'
            cand config 'Operations with the Taplo config file'
            cand get 'Extract a value from the given TOML document'
            cand toml-test 'Start a decoder for `toml-test` (https://github.com/BurntSushi/toml-test)'
            cand completions 'Generate completions for Taplo CLI'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;lint'= {
            cand -c 'Path to the Taplo configuration file'
            cand --config 'Path to the Taplo configuration file'
            cand --cache-path 'Set a cache path'
            cand --schema 'URL to the schema to be used for validation'
            cand --schema-catalog 'URL to a schema catalog (index) that is compatible with Schema Store or Taplo catalogs'
            cand --colors 'colors'
            cand --no-auto-config 'Do not search for a configuration file'
            cand --default-schema-catalogs 'Use the default online catalogs for schemas'
            cand --no-schema 'Disable all schema validations'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;format'= {
            cand -c 'Path to the Taplo configuration file'
            cand --config 'Path to the Taplo configuration file'
            cand --cache-path 'Set a cache path'
            cand -o 'A formatter option given as a "key=value", can be set multiple times'
            cand --option 'A formatter option given as a "key=value", can be set multiple times'
            cand --stdin-filepath 'A path to the file that the Taplo CLI will treat like stdin'
            cand --colors 'colors'
            cand --no-auto-config 'Do not search for a configuration file'
            cand -f 'Ignore syntax errors and force formatting'
            cand --force 'Ignore syntax errors and force formatting'
            cand --check 'Dry-run and report any files that are not correctly formatted'
            cand --diff 'Print the differences in patch formatting to `stdout`'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;lsp'= {
            cand -c 'Path to the Taplo configuration file'
            cand --config 'Path to the Taplo configuration file'
            cand --cache-path 'Set a cache path'
            cand --colors 'colors'
            cand --no-auto-config 'Do not search for a configuration file'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand tcp 'Run the language server and listen on a TCP address'
            cand stdio 'Run the language server over the standard input and output'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;lsp;tcp'= {
            cand --address 'The address to listen on'
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;lsp;stdio'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;lsp;help'= {
            cand tcp 'Run the language server and listen on a TCP address'
            cand stdio 'Run the language server over the standard input and output'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;lsp;help;tcp'= {
        }
        &'taplo;lsp;help;stdio'= {
        }
        &'taplo;lsp;help;help'= {
        }
        &'taplo;config'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand default 'Print the default `.taplo.toml` configuration file'
            cand schema 'Print the JSON schema of the `.taplo.toml` configuration file'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;config;default'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;config;schema'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;config;help'= {
            cand default 'Print the default `.taplo.toml` configuration file'
            cand schema 'Print the JSON schema of the `.taplo.toml` configuration file'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;config;help;default'= {
        }
        &'taplo;config;help;schema'= {
        }
        &'taplo;config;help;help'= {
        }
        &'taplo;get'= {
            cand -o 'The format specifying how the output is printed'
            cand --output-format 'The format specifying how the output is printed'
            cand -f 'Path to the TOML document, if omitted the standard input will be used'
            cand --file-path 'Path to the TOML document, if omitted the standard input will be used'
            cand --separator 'A string that separates array values when printing to stdout'
            cand --colors 'colors'
            cand -s 'Strip the trailing newline from the output'
            cand --strip-newline 'Strip the trailing newline from the output'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;toml-test'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;completions'= {
            cand --colors 'colors'
            cand --verbose 'Enable a verbose logging format'
            cand --log-spans 'Enable logging spans'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'taplo;help'= {
            cand lint 'Lint TOML documents'
            cand format 'Format TOML documents'
            cand lsp 'Language server operations'
            cand config 'Operations with the Taplo config file'
            cand get 'Extract a value from the given TOML document'
            cand toml-test 'Start a decoder for `toml-test` (https://github.com/BurntSushi/toml-test)'
            cand completions 'Generate completions for Taplo CLI'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'taplo;help;lint'= {
        }
        &'taplo;help;format'= {
        }
        &'taplo;help;lsp'= {
            cand tcp 'Run the language server and listen on a TCP address'
            cand stdio 'Run the language server over the standard input and output'
        }
        &'taplo;help;lsp;tcp'= {
        }
        &'taplo;help;lsp;stdio'= {
        }
        &'taplo;help;config'= {
            cand default 'Print the default `.taplo.toml` configuration file'
            cand schema 'Print the JSON schema of the `.taplo.toml` configuration file'
        }
        &'taplo;help;config;default'= {
        }
        &'taplo;help;config;schema'= {
        }
        &'taplo;help;get'= {
        }
        &'taplo;help;toml-test'= {
        }
        &'taplo;help;completions'= {
        }
        &'taplo;help;help'= {
        }
    ]
    $completions[$command]
}
