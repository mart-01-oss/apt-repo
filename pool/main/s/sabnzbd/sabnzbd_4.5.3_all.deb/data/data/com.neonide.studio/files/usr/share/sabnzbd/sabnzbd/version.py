# This file will be patched by setup.py
# The __version__ should be set to the branch name
# Leave __baseline__ set to unknown to enable setting commit-hash
# (e.g. "develop" or "1.2.x")

# You MUST use double quotes (so " and not ')
# Do not forget to update the appdata file for every major release!

__version__ = "4.5.3"
__baseline__ = "825322baa44f23dd1fe278b36610ba7d0e95d3c8"
