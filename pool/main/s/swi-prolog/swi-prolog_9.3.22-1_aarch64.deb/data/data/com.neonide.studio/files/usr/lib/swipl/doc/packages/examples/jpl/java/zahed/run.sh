#!/data/data/com.neonide.studio/files/usr/bin/sh

. ../env.sh

run Zahed

