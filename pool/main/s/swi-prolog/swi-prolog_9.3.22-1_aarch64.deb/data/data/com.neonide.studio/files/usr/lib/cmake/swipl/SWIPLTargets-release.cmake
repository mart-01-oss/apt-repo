#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "swipl::swipl" for configuration "Release"
set_property(TARGET swipl::swipl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(swipl::swipl PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/swipl/bin/arm64-android/swipl"
  )

list(APPEND _cmake_import_check_targets swipl::swipl )
list(APPEND _cmake_import_check_files_for_swipl::swipl "${_IMPORT_PREFIX}/lib/swipl/bin/arm64-android/swipl" )

# Import target "swipl::libswipl" for configuration "Release"
set_property(TARGET swipl::libswipl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(swipl::libswipl PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libswipl.so"
  IMPORTED_SONAME_RELEASE "libswipl.so"
  )

list(APPEND _cmake_import_check_targets swipl::libswipl )
list(APPEND _cmake_import_check_files_for_swipl::libswipl "/data/data/com.neonide.studio/files/usr/lib/libswipl.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
