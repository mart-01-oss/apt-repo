/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(rl_read_init_file(?), readline, readline).
index(rl_add_history(?), readline, readline).
index(rl_write_history(?), readline, readline).
index(rl_read_history(?), readline, readline).
