#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KeyFinder::keyfinder" for configuration "Release"
set_property(TARGET KeyFinder::keyfinder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KeyFinder::keyfinder PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.neonide.studio/files/usr/lib/libkeyfinder.so"
  IMPORTED_SONAME_RELEASE "libkeyfinder.so"
  )

list(APPEND _cmake_import_check_targets KeyFinder::keyfinder )
list(APPEND _cmake_import_check_files_for_KeyFinder::keyfinder "/data/data/com.neonide.studio/files/usr/lib/libkeyfinder.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
